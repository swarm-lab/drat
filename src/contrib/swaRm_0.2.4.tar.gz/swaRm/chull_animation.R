library(dplyr)
library(swaRm)
library(ggplot2)
library(gganimate)
library(ggmap)

filePaths <- dir(system.file("extdata", package = "swaRm"), full.names = TRUE)

trajs <- lapply(filePaths, function(path) {
  dat <- read.csv(path) 
  makeTraj(x = dat$lon, y = dat$lat, date = dat$date, time = dat$time,
           id = gsub(".*/|.csv.*", "\\1", path), geo = TRUE) %>%
    fixTIMEDUP() %>% fixMISSING() %>% fixTIMESEQ() %>% 
    fixTIMENA() %>% fixLOCSEQ() %>% fixLOCNA() %>%
    mutate(linDist = linDist(lon, lat, geo = TRUE)) %>%
    mutate(cumDist = cumsum(linDist)) %>%
    mutate(linSpeed = linSpeed(lon, lat, time, geo = TRUE),
           linAcc = linAcc(lon, lat, time, geo = TRUE),
           heading = heading(lon, lat, geo = TRUE),
           angSpeed = angSpeed(lon, lat, time, geo = TRUE),
           angAcc = angAcc(lon, lat, time, geo = TRUE))
}) %>% data.table::rbindlist()

trajs <- group_by(trajs, time) %>%
  mutate(isChull = isChull(lon, lat))

myLocation <- c(lon = mean(range(trajs$lon)), lat = mean(range(trajs$lat)))
myMap <- get_map(location = myLocation, source = "google", 
                 maptype = "satellite", zoom = 17, scale = 2)

g <- ggmap(myMap) + 
  geom_polygon(data = arrange(filter(trajs, isChull > 0), isChull), 
               aes(x = lon, y = lat, frame = time), fill = "red", alpha = 0.25) +
  geom_point(data = trajs, aes(x = lon, y = lat, frame = time), size = 3, color = "white") + 
  geom_point(data = trajs, aes(x = lon, y = lat, color = id, frame = time), size = 2) + 
  xlab("Longitude") + ylab("Latitude") +
  xlim(min(trajs$lon), max(trajs$lon)) + 
  ylim(min(trajs$lat), max(trajs$lat)) + 
  guides(color = FALSE) + 
  theme(axis.line = element_blank(), axis.text = element_blank(),
        axis.ticks = element_blank(), axis.title = element_blank())

gganimate::gg_animate(g, "test.mp4", interval = 1/25, ani.width = 800, ani.height = 600, 
                      other.opts = "-profile:v high -s:v 800x600 -pix_fmt yuv420p -crf 20")



