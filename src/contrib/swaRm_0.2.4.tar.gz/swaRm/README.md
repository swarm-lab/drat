<img src="inst/img/logo.png" width="20%">

---

### General description

`swaRm` is a R package meant to standardized and accelerate the processing of 
data describing the movements of animal and human groups (e.g. fish schools, 
bird flocks). 

---

`swarm` is a work in progress. Functions are not yet in a stable state and are 
likely to change as the package gets developed. 

A vignette presenting the general functioning of the package can be found at 
[http://rpubs.com/sjmgarnier/swaRm](http://rpubs.com/sjmgarnier/swaRm).

---