#' @title ROpenCV: A package to install OpenCV within R
#'
#' @description This is a utility package that installs OpenCV within R for use
#'  by other packages.
#'
#' @author Simon Garnier, \email{garnier@@njit.edu}
#'
"_PACKAGE"
#> [1] "_PACKAGE"