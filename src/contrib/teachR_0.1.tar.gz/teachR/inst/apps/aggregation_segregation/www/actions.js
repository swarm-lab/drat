$(document).ready(function() {
  
  jQuery(function($){
    $("a[data-value='RStudio']").attr("href", "http://www.rstudio.com");
    $("a[data-value='RStudio']").attr("data-toggle", "");
  });
  
});





