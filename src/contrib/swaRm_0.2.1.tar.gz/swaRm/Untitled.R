library(data.table)
library(dplyr)
library(ggplot2)

files <- dir("~/Google Drive/NJIT/Work/research/goats/namibia2015/data/raw",
             pattern = "*.csv", full.names = TRUE)

base <- lapply(files, function(path) {
  dt <- fread(path) 
  makeTraj(x = dt$V3, y = dt$V4, date = dt$V1, time = dt$V2,
           id = gsub(".*_|.csv.*", "\\1", path), geo = TRUE) %>%
    mutate(dist = linDist(lon, lat, geo = TRUE)) %>%
    mutate(cumDist = cumsum(dist)) %>%
    mutate(speed = linSpeed(lon, lat, time, geo = TRUE),
           acc = linAcc(lon, lat, time, geo = TRUE),
           heading = heading(lon, lat, geo = TRUE),
           angSpeed = angSpeed(lon, lat, time, geo = TRUE),
           angAcc = angAcc(lon, lat, time, geo = TRUE))
}) %>% rbindlist()

base <- group_by(base, time) %>%
  mutate(distCentroid = dist2centroid(lon, lat, geo = TRUE),
         isChull = isChull(lon, lat)) 

test <- group_by(base, time) %>%
  do(nn = nn(lon, lat, geo = TRUE))

plop <- filter(test, time == "2015-09-10 07:46:17")
ggplot(plop, aes(x = lon, y = lat, color = isChull, fill = isChull)) +
  geom_point() + coord_fixed()







### ###
l <- 1:16
dat <- lapply(l, function(l, path) {
  dt <- fread(path[l]) %>%
    select(1:4) %>%
    rename(date = V1, time = V2, lon = V3, lat = V4) %>%
    filter(time > "06:59:59", time < "08:00:00")
  
  write.csv(dt, file = sprintf("inst/extdata/%02d.csv", l), row.names = FALSE)
  
}, path = files)









