swarmR
======

A R package to process and analyze collective behavior data
